package ru.ostrov77.lobby;


import org.bukkit.Material;
import org.bukkit.entity.Player;
import ru.komiss77.utils.ItemBuilder;
import ru.komiss77.utils.inventory.ClickableItem;
import ru.komiss77.utils.inventory.InventoryContent;
import ru.komiss77.utils.inventory.InventoryProvider;



public class OsComMenu implements InventoryProvider {
    
    
    public OsComMenu() {
    }
    
    
    
    @Override
    public void init(final Player p, final InventoryContent contents) {
        //p.playSound(p.getLocation(), Sound.BLOCK_COMPARATOR_CLICK, 5, 5);
        //contents.fillRect(0,0, 2,3, ClickableItem.empty(fill1));
        

        

      /*  
        
        contents.set(0, ClickableItem.of(new ItemBuilder(Material.REDSTONE)
            .name("§6Локации")
            .lore("§7ЛКМ - открыть")
            .lore("")
            .build(), e -> {
                

            }
        ));        
      

        contents.set(0, ClickableItem.of(new ItemBuilder(Material.REDSTONE)
            .name("§3Задания")
            .lore("§7ЛКМ - открыть")
            .lore("")
            .build(), e -> {
                

            }
        ));        
      


        
        
        
        
        contents.set(4, ClickableItem.of(new ItemBuilder(Material.REDSTONE)
            .name("§cПропустить интро")
            .lore("§7ЛКМ - пропустить")
            .lore("")
            .build(), e -> {
                p.closeInventory();
                NewBie.stop(p);

            }
        ));
        
        */

   

  

        

        


        
        

    }
    
    
    
    
    
    
    
    
    
    
}
