package ru.ostrov77.lobby.bots.spots;

public enum SpotType {
	SPAWN, WALK, END;
}
